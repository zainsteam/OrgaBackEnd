<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['error_prefix'] = '';
$config['error_suffix'] = '';
?>